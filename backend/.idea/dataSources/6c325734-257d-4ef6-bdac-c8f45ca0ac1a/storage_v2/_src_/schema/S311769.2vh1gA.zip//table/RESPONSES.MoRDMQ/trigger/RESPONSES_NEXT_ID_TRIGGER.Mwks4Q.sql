create trigger RESPONSES_NEXT_ID_TRIGGER
    before insert
    on RESPONSES
    for each row
begin
select RESPONSES_NEXT_ID.nextval
into :new.id
from dual;
end;
/

