create trigger USERS_NEXT_ID_TRIGGER
    before insert
    on USERS
    for each row
begin
select USERS_NEXT_ID.nextval
into :new.id
from dual;
end;
/

